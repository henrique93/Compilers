// $Id: factory.cpp,v 1.1 2016/02/19 19:29:48 david Exp $ -*- c++ -*-

#include "factory.h"

/**
 * This object is automatically registered by the constructor in the
 * superclass' language registry.
 */
zu::factory zu::factory::_self;
