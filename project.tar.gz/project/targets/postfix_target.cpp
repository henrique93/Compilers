// $Id: postfix_target.cpp,v 1.1 2016/02/19 19:29:48 david Exp $
#include "targets/postfix_target.h"

/**
 * Postfix for ix86.
 * @var create and register an evaluator for ASM targets.
 */
zu::postfix_target zu::postfix_target::_self;
