// $Id: postfix_writer.cpp,v 1.35 2016/05/20 15:21:05 ist177459 Exp $ -*- c++ -*-
#include <string>
#include <sstream>
#include "targets/type_checker.h"
#include "targets/postfix_writer.h"
#include "ast/all.h"  // all.h is automatically generated
#include "targets/postfix_size.h"

//---------------------------------------------------------------------------
//     THIS IS THE VISITOR'S DEFINITION
//---------------------------------------------------------------------------

void zu::postfix_writer::do_sequence_node(cdk::sequence_node * const node, int lvl) {
  for (size_t i = 0; i < node->size(); i++) {
    node->node(i)->accept(this, lvl);
  }
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_integer_node(cdk::integer_node * const node, int lvl) {
  _pf.INT(node->value()); // push an integer
}

void zu::postfix_writer::do_string_node(cdk::string_node * const node, int lvl) {
  int lbl1;

  /* generate the string */
  _pf.RODATA(); // strings are DATA readonly
  _pf.ALIGN(); // make sure we are aligned
  _pf.LABEL(mklbl(lbl1 = ++_lbl)); // give the string a name
  _pf.STR(node->value()); // output string characters

  /* leave the address on the stack */
  _pf.TEXT(); // return to the TEXT segment
  _pf.ADDR(mklbl(lbl1)); // the string to be printed
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_neg_node(cdk::neg_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->argument()->accept(this, lvl); // determine the value
  _pf.NEG(); // 2-complement
}

void zu::postfix_writer::do_id_node(zu::id_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->argument()->accept(this, lvl); // determine the value
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_continue_node(zu::continue_node * const node, int lvl) {
    //_pf.JMP(mklbl(_continue.top())); FIXME commented not to get stuck on tests
}

void zu::postfix_writer::do_break_node(zu::break_node * const node, int lvl) {
    //_pf.JMP(mklbl(_break.top())); FIXME commented not to get seg fault on tests
}

void zu::postfix_writer::do_return_node(zu::return_node * const node, int lvl) {
    // FIXME
}

void zu::postfix_writer::do_function_call_node(zu::function_call_node * const node, int lvl) {
    // FIXME
}

void zu::postfix_writer::do_function_dec_node(zu::function_dec_node * const node, int lvl) {
    // FIXME
}



void zu::postfix_writer::do_add_node(cdk::add_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.ADD();
}
void zu::postfix_writer::do_sub_node(cdk::sub_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.SUB();
}
void zu::postfix_writer::do_mul_node(cdk::mul_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.MUL();
}
void zu::postfix_writer::do_div_node(cdk::div_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.DIV();
}
void zu::postfix_writer::do_mod_node(cdk::mod_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.MOD();
}
void zu::postfix_writer::do_lt_node(cdk::lt_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.LT();
}
void zu::postfix_writer::do_le_node(cdk::le_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.LE();
}
void zu::postfix_writer::do_ge_node(cdk::ge_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.GE();
}
void zu::postfix_writer::do_gt_node(cdk::gt_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.GT();
}
void zu::postfix_writer::do_ne_node(cdk::ne_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.NE();
}
void zu::postfix_writer::do_eq_node(cdk::eq_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  node->right()->accept(this, lvl);
  _pf.EQ();
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_and_node(zu::and_node * const node, int lvl) {
  int lbl1;
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  _pf.JZ(mklbl(lbl1 = ++_lbl));
  node->right()->accept(this, lvl);
  _pf.ALIGN();
  _pf.LABEL(mklbl(lbl1));
}
void zu::postfix_writer::do_or_node(zu::or_node * const node, int lvl) {
  int lbl1;
  CHECK_TYPES(_compiler, _symtab, node);
  node->left()->accept(this, lvl);
  _pf.JNZ(mklbl(lbl1 = ++_lbl));
  node->right()->accept(this, lvl);
  _pf.ALIGN();
  _pf.LABEL(mklbl(lbl1));
}

void zu::postfix_writer::do_not_node(zu::not_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node); //FIXME
  node->argument()->accept(this, lvl);
  _pf.NOT();
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_pos_node(zu::pos_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node); //FIXME
  node->argument()->accept(this, lvl);
  _pf.OR();
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_index_node(zu::index_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  //_pf.ADDR(*(node->getVarName())); //FIXME
}
void zu::postfix_writer::do_malloc_node(zu::malloc_node * const node, int lvl) {
    //FIXME
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_rvalue_node(zu::rvalue_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->lvalue()->accept(this, lvl);

  _pf.LOAD(); //FIXME: depends on type size
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_lvalue_node(zu::lvalue_node * const node, int lvl) {
  //CHECK_TYPES(_compiler, _symtab, node);
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_assignment_node(zu::assignment_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);

  // DAVID: horrible hack!
  // (this is caused by Zu not having explicit variable declarations)
  node->rvalue()->accept(this, lvl); // determine the new value
  _pf.DUP();
  node->lvalue()->accept(this, lvl); // where to store the value
  _pf.STORE(); // store the value at address
}


void zu::postfix_writer::do_variable_node(zu::variable_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);

  std::shared_ptr<zu::symbol> s = _symtab.find(*(node->getVarName()));
  if(s.get() == NULL){
    std::cerr << "error: variable " << node->name() << " not declared" << std::endl;
    exit(-1);
  }
  s = _symtab.find(*(node->getVarName()));
  if(s.get() != NULL){
    if(s.get()->offset() != 0){
      //LOCAL
      _pf.LOCAL(s.get()->offset());
    }else{
      //GLOBAL
      _pf.ADDR(*(node->getVarName()));
      //Variable is global
    }
    //Variable is local

  }else{
    std::cerr << "var is not defined lvalue" << std::endl;
  }
  //FIXME
  //_pf.ADDRV(*(node->getVarName()));
}

void zu::postfix_writer::do_variable_dec_node(zu::variable_dec_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  _pf.BSS();
  _pf.ALIGN();
  _pf.GLOBAL(*(node->getVarName()), _pf.OBJ());
  _pf.LABEL(*(node->getVarName()));
  if (node->getType()->name() == basic_type::TYPE_INT) {
    _pf.BYTE(4);
  }
  else if (node->getType()->name() == basic_type::TYPE_DOUBLE) {
    _pf.BYTE(8);
  }
  else if (node->getType()->name() == basic_type::TYPE_STRING) {
    _pf.BYTE(4);
  }
}

void zu::postfix_writer::do_variable_def_node(zu::variable_def_node * const node, int lvl) {
   CHECK_TYPES(_compiler, _symtab, node);


  if (node->getType()->name() == basic_type::TYPE_INT) {
    _pf.DATA();
    _pf.ALIGN();
    _pf.GLOBAL(*(node->getVarName()), _pf.OBJ());
    _pf.LABEL(*(node->getVarName()));
    _pf.CONST(((cdk::simple_value_node<int>*)node->getValue())->value());
  }
  else if((node->getType()->name() == basic_type::TYPE_STRING)){
   _pf.RODATA();
   _pf.ALIGN();
   _pf.LABEL(mklbl(++_lbl));
   cdk::string_node *stringN = dynamic_cast<cdk::string_node*>(node->getValue());
    if(stringN == nullptr) {
      throw " string null pointer";
    }
   _pf.STR(stringN->value());

   /* leave the address on the stack */
   _pf.DATA();
   _pf.ALIGN();
   _pf.GLOBAL(*(node->getVarName()), _pf.OBJ());
   _pf.LABEL(*(node->getVarName()));
   _pf.ID(mklbl(_lbl));
   _pf.TEXT();


    }else if((node->getType()->name() == basic_type::TYPE_DOUBLE)){
      _pf.DOUBLE(((cdk::simple_value_node<double>*)node->getValue())->value());
    }else if(node->getType()->name() == basic_type::TYPE_POINTER){
      _pf.INT(0);
    }

  _pf.TEXT();
  _pf.ALIGN();
  // FIXME
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_function_def_node(zu::function_def_node * const node, int lvl) {   // Note that Zu doesn't have functions. Thus, it doesn't need
  // a function node. However, it must start in the main function.
  // The ProgramNode (representing the whole program) doubles as a
  // main function node.

  // generate the main function (RTS mandates that its name be "_main")
  _pf.TEXT();
  _pf.ALIGN();
  _pf.GLOBAL("_main", _pf.FUNC());
  _pf.LABEL("_main");
  zu::postfix_size sizeVisitor(_compiler);
  (node)->accept(&sizeVisitor, 0);
  _pf.ENTER(sizeVisitor.value());  // Zu doesn't implement local variables

  node->getBlock()->accept(this, lvl);

  // end the main function
  _pf.INT(0);
  _pf.POP();
  _pf.LEAVE();
  _pf.RET();

  // these are just a few library function imports
  _pf.EXTERN("readi");
  _pf.EXTERN("printi");
  _pf.EXTERN("prints");
  _pf.EXTERN("println");
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_evaluation_node(zu::evaluation_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->argument()->accept(this, lvl); // determine the value
  if (node->argument()->type()->name() == basic_type::TYPE_INT) {
    _pf.TRASH(4); // delete the evaluated value
  }
  else if (node->argument()->type()->name() == basic_type::TYPE_STRING) {
    _pf.TRASH(4); // delete the evaluated value's address
  }
  else {
    std::cerr << "ERROR: CANNOT HAPPEN(eval)!" << std::endl;
    exit(1);
  }
}

void zu::postfix_writer::do_println_node(zu::println_node * const node, int lvl) {
  do_print_node( node ,lvl);
  _pf.CALL("println"); // print a newline
}


void zu::postfix_writer::do_print_node(zu::print_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  node->argument()->accept(this, lvl); // determine the value to print
  if (node->argument()->type()->name() == basic_type::TYPE_INT) {
    _pf.CALL("printi");
    _pf.TRASH(4); // delete the printed value
  }
  else if (node->argument()->type()->name() == basic_type::TYPE_STRING) {
    _pf.CALL("prints");
    _pf.TRASH(4); // delete the printed value's address
  }  else if (node->argument()->type()->name() == basic_type::TYPE_DOUBLE) {
    _pf.CALL("printd");
    _pf.TRASH(8); // delete the printed value's address
  }
  else {
    std::cerr << "ERROR: CANNOT HAPPEN!(print)" << std::endl;
    exit(1);
  }
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_read_node(zu::read_node * const node, int lvl) {
  CHECK_TYPES(_compiler, _symtab, node);
  _pf.CALL("readi");
  _pf.PUSH();
  node->accept(this, lvl);
  _pf.STORE();
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_for_node(zu::for_node * const node, int lvl) {
  int lbl1, lbl2;
  if (node->init() != nullptr) 
  node->init()->accept(this, lvl);
  _pf.LABEL(mklbl(lbl1 = ++_lbl));
  _continue.push(lbl1);
  if (node->condition() != nullptr)
  node->condition()->accept(this, lvl + 1);
  _pf.JZ(mklbl(lbl2 = ++_lbl));
  node->block()->accept(this, lvl + 2);
  if (node->increment() != nullptr)
  node->increment()->accept(this, lvl + 3);
  _pf.JMP(mklbl(lbl1));
  _pf.LABEL(mklbl(lbl2));
  _break.push(lbl2);
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_if_node(zu::if_node * const node, int lvl) {
  int lbl1;
  node->condition()->accept(this, lvl);
  _pf.JZ(mklbl(lbl1 = ++_lbl));
  node->block()->accept(this, lvl + 2);
  _pf.LABEL(mklbl(lbl1));
}

//---------------------------------------------------------------------------

void zu::postfix_writer::do_if_else_node(zu::if_else_node * const node, int lvl) {
  int lbl1, lbl2;
  node->condition()->accept(this, lvl);
  _pf.JZ(mklbl(lbl1 = ++_lbl));
  node->thenblock()->accept(this, lvl + 2);
  _pf.JMP(mklbl(lbl2 = ++_lbl));
  _pf.LABEL(mklbl(lbl1));
  node->elseblock()->accept(this, lvl + 2);
  _pf.LABEL(mklbl(lbl1 = lbl2));
}
