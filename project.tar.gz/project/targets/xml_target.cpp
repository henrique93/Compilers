// $Id: xml_target.cpp,v 1.1 2016/02/19 19:29:48 david Exp $
#include "targets/xml_target.h"

/** @var create and register an XML targets. */
zu::xml_target zu::xml_target::_self;
