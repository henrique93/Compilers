// $Id: zu_scanner.h,v 1.1 2016/02/19 19:29:48 david Exp $ -*- c++ -*-
#ifndef __ZUSCANNER_H__
#define __ZUSCANNER_H__

#undef yyFlexLexer
#define yyFlexLexer zu_scanner
#include <FlexLexer.h>

#endif
